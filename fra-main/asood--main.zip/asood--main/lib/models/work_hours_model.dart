class WorkHours {
  String? fromSat;
  String? toSat;
  String? fromSun;
  String? toSun;
  String? fromMon;
  String? toMon;
  String? fromTue;
  String? toTue;
  String? fromWed;
  String? toWed;
  String? fromThu;
  String? toThu;
  String? fromFri;
  String? toFri;

  WorkHours({
    this.fromSat,
    this.toSat,
    this.fromSun,
    this.toSun,
    this.fromMon,
    this.toMon,
    this.fromTue,
    this.toTue,
    this.fromWed,
    this.toWed,
    this.fromThu,
    this.toThu,
    this.fromFri,
    this.toFri,
  });
}
