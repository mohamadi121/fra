///in this folder we use bloc for our app logics 
///whole things here should be  logic only NO UI OR WIDGETS