class PanelRepo {
  // final PanelAPIService panelApiService = PanelAPIService();
}