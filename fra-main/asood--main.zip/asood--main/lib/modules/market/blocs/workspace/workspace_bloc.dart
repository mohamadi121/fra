// import 'package:bloc/bloc.dart';
// import 'package:equatable/equatable.dart';
//
// part 'workspace_event.dart';
// part 'workspace_state.dart';
//
// class WorkspaceBloc extends Bloc<WorkspaceEvent, WorkspaceState> {
//   WorkspaceBloc() : super(WorkspaceInitial()) {
//     on<WorkspaceEvent>((event, emit) {});
//
//     on<CreateWorkspace>((event, emit) {});
//
//     on<UpdateWorkspace>((event, emit) {});
//
//     on<DeleteWorkspace>((event, emit) {});
//
//     on<LoadWorkspace>((event, emit) {});
//   }
// }
