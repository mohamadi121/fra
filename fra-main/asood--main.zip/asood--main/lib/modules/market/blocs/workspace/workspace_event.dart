// part of 'workspace_bloc.dart';
//
// sealed class WorkspaceEvent extends Equatable {
//   const WorkspaceEvent();
//
//   @override
//   List<Object> get props => [];
// }
//
// final class CreateWorkspace extends WorkspaceEvent {}
//
// final class UpdateWorkspace extends WorkspaceEvent {}
//
// final class DeleteWorkspace extends WorkspaceEvent {}
//
// final class LoadWorkspace extends WorkspaceEvent {}
