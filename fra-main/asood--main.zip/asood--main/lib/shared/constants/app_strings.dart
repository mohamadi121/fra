part of constants;

abstract class AppStrings {
  AppStrings._();
  static const Map<String, String> simpleHeader = {
    'Content-Type': 'application/json; charset=UTF-8',
  };
}
