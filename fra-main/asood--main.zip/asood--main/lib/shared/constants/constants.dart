library constants;

import 'package:flutter/material.dart';

part "dimensions.dart";
part 'app_colors.dart';
part 'app_strings.dart';
part 'assets.gen.dart';
part 'decorations.dart';
part 'extentions.dart';
part 'fonts.gen.dart';
part 'text_styles.dart';
part 'themes.dart';
part 'menu_painter.dart';
